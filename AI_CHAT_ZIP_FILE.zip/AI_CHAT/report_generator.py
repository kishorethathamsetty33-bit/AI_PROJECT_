from io import BytesIO

from docx import Document

from docx.enum.text import WD_ALIGN_PARAGRAPH

from docx.shared import Pt

from comparison import ComparisonResult


def add_bullet(
    document,
    text: str,
):
    """
    Add a bullet point to the document.
    """

    paragraph = document.add_paragraph(
        style="List Bullet"
    )

    paragraph.add_run(
        text
    )


def create_docx_report(
    result: ComparisonResult,
    file_name_a: str,
    file_name_b: str,
) -> bytes:
    """
    Create a DOCX comparison report in memory.

    Returns:
        DOCX file bytes.
    """

    document = Document()


    # -----------------------------------------------------
    # TITLE
    # -----------------------------------------------------

    title = document.add_heading(
        "AI Document Comparison Report",
        level=0,
    )

    title.alignment = (
        WD_ALIGN_PARAGRAPH.CENTER
    )


    # -----------------------------------------------------
    # DOCUMENT INFORMATION
    # -----------------------------------------------------

    document.add_heading(
        "Document Information",
        level=1,
    )

    paragraph = document.add_paragraph()

    paragraph.add_run(
        "Document A: "
    ).bold = True

    paragraph.add_run(
        file_name_a
    )


    paragraph = document.add_paragraph()

    paragraph.add_run(
        "Document B: "
    ).bold = True

    paragraph.add_run(
        file_name_b
    )


    # -----------------------------------------------------
    # SUMMARY A
    # -----------------------------------------------------

    document.add_heading(
        "Document A — Summary",
        level=1,
    )

    document.add_paragraph(
        result.document_a_summary
    )


    # -----------------------------------------------------
    # SUMMARY B
    # -----------------------------------------------------

    document.add_heading(
        "Document B — Summary",
        level=1,
    )

    document.add_paragraph(
        result.document_b_summary
    )


    # -----------------------------------------------------
    # SIMILARITIES
    # -----------------------------------------------------

    document.add_heading(
        "Similarities",
        level=1,
    )

    if result.similarities:

        for similarity in result.similarities:

            add_bullet(
                document,
                similarity,
            )

    else:

        document.add_paragraph(
            "No meaningful similarities were identified."
        )


    # -----------------------------------------------------
    # DIFFERENCES
    # -----------------------------------------------------

    document.add_heading(
        "Differences",
        level=1,
    )

    if result.differences:

        for index, difference in enumerate(
            result.differences,
            start=1,
        ):

            document.add_heading(
                f"Difference {index}: {difference.type}",
                level=2,
            )

            document.add_paragraph(
                difference.description
            )


            paragraph = document.add_paragraph()

            paragraph.add_run(
                "Document A: "
            ).bold = True

            paragraph.add_run(
                difference.document_a
            )


            paragraph = document.add_paragraph()

            paragraph.add_run(
                "Document B: "
            ).bold = True

            paragraph.add_run(
                difference.document_b
            )


            if difference.evidence:

                paragraph = document.add_paragraph()

                paragraph.add_run(
                    "Evidence: "
                ).bold = True

                paragraph.add_run(
                    difference.evidence
                )

    else:

        document.add_paragraph(
            "No meaningful differences were identified."
        )


    # -----------------------------------------------------
    # KEY DETAILS
    # -----------------------------------------------------

    document.add_heading(
        "Key Details Comparison",
        level=1,
    )

    if result.key_details:

        table = document.add_table(
            rows=1,
            cols=4,
        )

        table.style = "Table Grid"


        headers = table.rows[0].cells

        headers[0].text = "Field"
        headers[1].text = "Document A"
        headers[2].text = "Document B"
        headers[3].text = "Comparison"


        for detail in result.key_details:

            row = table.add_row().cells

            row[0].text = detail.field

            row[1].text = detail.document_a

            row[2].text = detail.document_b

            row[3].text = detail.comparison

    else:

        document.add_paragraph(
            "No key details were identified."
        )


    # -----------------------------------------------------
    # CONCLUSION
    # -----------------------------------------------------

    document.add_heading(
        "Overall Conclusion",
        level=1,
    )

    document.add_paragraph(
        result.overall_conclusion
    )


    # -----------------------------------------------------
    # LIMITATIONS
    # -----------------------------------------------------

    document.add_heading(
        "Limitations",
        level=1,
    )

    if result.limitations:

        for limitation in result.limitations:

            add_bullet(
                document,
                limitation,
            )

    else:

        document.add_paragraph(
            "No additional limitations were reported."
        )


    # -----------------------------------------------------
    # DISCLAIMER
    # -----------------------------------------------------

    document.add_heading(
        "Disclaimer",
        level=1,
    )

    document.add_paragraph(
        "This application provides an informational "
        "comparison based on the text extracted from "
        "the supplied documents. It is not a legal "
        "decision-maker and does not determine whether "
        "a document is legally safe, compliant, or "
        "equivalent to another document."
    )


    # -----------------------------------------------------
    # BASIC FONT
    # -----------------------------------------------------

    styles = document.styles

    normal_style = styles["Normal"]

    normal_style.font.name = "Arial"

    normal_style.font.size = Pt(10)


    # -----------------------------------------------------
    # SAVE TO MEMORY
    # -----------------------------------------------------

    output = BytesIO()

    document.save(output)

    output.seek(0)

    return output.getvalue()