from typing import Tuple

from pypdf import PdfReader


# Maximum total characters that this application will send
# to the LLM in one comparison.
#
# This is an application-level safety limit, not a claim about
# Gemini's absolute context limit.
MAX_TOTAL_CHARS = 120_000


def validate_pdf(uploaded_file) -> Tuple[bool, str]:
    """
    Validate that the uploaded file is a usable PDF.
    """

    if uploaded_file is None:

        return False, "No file was uploaded."


    file_name = uploaded_file.name.lower()


    if not file_name.endswith(".pdf"):

        return False, "Only PDF files are supported."


    # Move pointer to beginning
    uploaded_file.seek(0)

    file_bytes = uploaded_file.read()

    uploaded_file.seek(0)


    if not file_bytes:

        return False, "The uploaded PDF is empty."


    try:

        reader = PdfReader(uploaded_file)

        if len(reader.pages) == 0:

            return False, "The PDF contains no pages."


    except Exception:

        return False, (
            "The PDF could not be opened. "
            "It may be corrupted or invalid."
        )


    uploaded_file.seek(0)

    return True, "Valid PDF."


def extract_text_from_pdf(uploaded_file) -> Tuple[str, int]:
    """
    Extract text from every page of a PDF.

    Returns:
        text: Combined text with page markers.
        page_count: Number of pages.
    """

    uploaded_file.seek(0)

    reader = PdfReader(uploaded_file)

    page_texts = []

    for page_number, page in enumerate(
        reader.pages,
        start=1
    ):

        try:

            text = page.extract_text()

        except Exception:

            text = ""


        if text:

            cleaned_text = text.strip()

        else:

            cleaned_text = ""


        page_texts.append(
            f"\n--- Page {page_number} ---\n"
            f"{cleaned_text}"
        )


    full_text = "\n".join(page_texts)

    uploaded_file.seek(0)

    return full_text.strip(), len(reader.pages)


def get_document_info(
    text: str,
    page_count: int,
) -> dict:
    """
    Return basic information about extracted text.
    """

    cleaned_text = text.strip()

    preview_length = 1500

    if len(cleaned_text) > preview_length:

        preview = (
            cleaned_text[:preview_length]
            + "\n..."
        )

    else:

        preview = cleaned_text


    return {
        "pages": page_count,
        "characters": len(cleaned_text),
        "preview": preview,
    }


def validate_combined_length(
    text_a: str,
    text_b: str,
) -> Tuple[bool, str]:

    total_characters = (
        len(text_a) + len(text_b)
    )


    if total_characters > MAX_TOTAL_CHARS:

        return (
            False,
            (
                "The combined extracted text is too long "
                "for this application's direct comparison mode. "
                f"Extracted characters: {total_characters:,}. "
                f"Application limit: {MAX_TOTAL_CHARS:,}. "
                "Please use shorter documents."
            ),
        )


    return True, "Text length is acceptable."